package org.iit.se.booklib.model;

import javax.annotation.Generated;

public class User {

	private String userId;
	private String passowrd;
	private String firstName;
	private String lastName;
	private String role;
	private String email;
	private String phoneNo;
	private String address;
	private String city;
	private String country;
	private String studentId;
	private String profId;
	private String parentsnName;
	private String parentsAdd;
	private String parentsContant;
	private String courseId;
	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassowrd() {
		return passowrd;
	}

	public void setPassowrd(String passowrd) {
		this.passowrd = passowrd;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getProfId() {
		return profId;
	}

	public void setProfId(String profId) {
		this.profId = profId;
	}

	public String getParentsnName() {
		return parentsnName;
	}

	public void setParentsnName(String parentsnName) {
		this.parentsnName = parentsnName;
	}

	public String getParentsAdd() {
		return parentsAdd;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public void setParentsAdd(String parentsAdd) {
		this.parentsAdd = parentsAdd;
	}

	public String getParentsContant() {
		return parentsContant;
	}

	public void setParentsContant(String parentsContant) {
		this.parentsContant = parentsContant;
	}

}
